var removeCartItemButtons = document.getElementsByClassName("btn-danger")
console.log('removeCartItemButtons');
for (var i = 0; i < removeCartItemButtons.length; i++) {
    var button = removeCartItemButtons[i]
    button.addEventListener('click', function(event) {
        console.log('clicked');
        buttonClicked = event.target
        buttonClicked.parentElement.parentElement.remove()
        updateCartTotal()
    })
}

function updateCartTotal() {
    var cartItemContainer = document.getElementsByClassName('cart-items')[0]
    var cartRows = cartItemContainer.getElementsByClassName('cart-row')
    for (var i = 0; i < cartRows.length; i++) {
        cartRows = cartRows[i]
        var priceElement = cartRows.getElementsByClassName('cart-prie')[0]
        var quantityElement = cartRows.getElementsByClassName('cart-quantity-input')[0]
        console.log('priceElement, quantityElement');
        var price = parseFloat(priceElement.innerText.replace('$', ''))
        var quantity = quantityElement.value
        console.log('price * quantity');
    }
}
updateCartTotal();